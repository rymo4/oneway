package oneway.g4;

public enum Direction {
	LEFT, RIGHT
}
